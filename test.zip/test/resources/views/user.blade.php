@extends('layouts.default')
 
 @section('content')
  
 Hi User with ID: {{ $userId }}
  
 @stop
