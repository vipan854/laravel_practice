@extends('layouts.default')
 
 @section('content')
  
  Welcome
  
 @stop